import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:travel_app/pages/home_page.dart';
import 'package:travel_app/pages/tourist_details_page.dart';
import 'package:travel_app/pages/welcome_page.dart.dart';
import 'package:travel_app/widgets/recommended_places.dart';
import 'package:travel_app/widgets/nearby_places.dart';
import './pages/login.dart';
import './pages/signup.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyDIel6QO28_CCUyMu5qqxqYuERTVeV1MIg",
            appId: "1:998654561193:web:2ab428af11af267be392b8",
            messagingSenderId: "998654561193",
            projectId: "travelapp-f61ae"));
  } else {
    await Firebase.initializeApp();
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/login',
      onGenerateRoute: (settings) {
        if (settings.name == '/touristDetail') {
          final args = settings.arguments as Map<String, dynamic>;
          return MaterialPageRoute(
            builder: (context) {
              return TouristDetailsPage(image: args['image']);
            },
          );
        }
        return MaterialPageRoute(
          builder: (context) {
            switch (settings.name) {
              case '/home':
                return const HomePage();
              case '/recommendedPlaces':
                return Scaffold(
                  appBar: AppBar(title: const Text('Recommended Places')),
                  body: RecommendedPlaces(),
                );
              case '/nearbyPlaces':
                return Scaffold(
                  appBar: AppBar(title: const Text('Nearby Places')),
                  body: NearbyPlaces(),
                );
              case '/':
              default:
                return const WelcomePage();
            }
          },
        );
      },
      routes: {
        "/login": (context) => const LoginScreen(),
        "/signup": (context) => const SignupScreen(),
        "/": (context) => const WelcomePage(),
        "/home": (context) => const HomePage(),
      },
      title: 'Travel App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: GoogleFonts.mulishTextTheme(
          Theme.of(context).textTheme,
        ),
      ),
    );
  }
}
