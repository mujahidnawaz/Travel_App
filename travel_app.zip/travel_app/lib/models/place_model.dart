class PlaceModel {
  final String name;
  final String image;

  PlaceModel({required this.name, required this.image});
}
