import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:travel_app/models/place_model.dart';
import 'package:travel_app/widgets/custom_icon_button.dart';
import 'package:travel_app/widgets/location_card.dart';
import 'package:travel_app/widgets/nearby_places.dart';
import 'package:travel_app/widgets/recommended_places.dart';
import 'package:travel_app/pages/tourist_details_page.dart';
import 'package:travel_app/widgets/tourist_places.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _searchController = TextEditingController();
  List<PlaceModel> _allPlaces = [];
  List<PlaceModel> _filteredPlaces = [];

  @override
  void initState() {
    super.initState();
    _allPlaces = [
      PlaceModel(name: 'Hunza Valley', image: 'assets/places/hunzavalley.jpg'),
      PlaceModel(name: 'Naran', image: 'assets/places/naran.jpg'),
      PlaceModel(name: 'Swat Valley', image: 'assets/places/swatvalley.jpg'),
      PlaceModel(name: 'Murree', image: 'assets/places/murree.jpg'),
      PlaceModel(
          name: 'Badshai Mosque', image: 'assets/places/badshaimosque.jpg'),
      PlaceModel(
          name: 'Masjid Wazeer Khan',
          image: 'assets/places/masjidwazeerkhan.jpg'),
      PlaceModel(
          name: 'Lahore Meuseum', image: 'assets/places/lahoremeuseum.jpg'),
      // Add more places here
    ];
    _filteredPlaces = _allPlaces;
  }

  void _filterPlaces(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredPlaces = _allPlaces;
      } else {
        _filteredPlaces = _allPlaces
            .where((place) =>
                place.name.toLowerCase().contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Good Morning"),
            Text(
              "Government College University Lahore",
              style: Theme.of(context).textTheme.labelMedium,
            ),
          ],
        ),
        actions: [
          CustomIconButton(
            icon: const Icon(Ionicons.search_outline),
            onPressed: () {
              showSearch(context: context, delegate: PlacesSearch(_allPlaces));
            },
          ),
          Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 12),
            child: CustomIconButton(
              icon: const Icon(Ionicons.notifications_outline),
              onPressed: () {
                // Handle notifications button press
              },
            ),
          ),
        ],
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(14),
        children: [
          // LOCATION CARD
          const LocationCard(),
          const SizedBox(
            height: 15,
          ),
          const TouristPlaces(),
          // CATEGORIES
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Recommendation",
                style: Theme.of(context).textTheme.titleLarge,
              ),
              TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, "/recommendedPlaces");
                },
                child: const Text("View All"),
              ),
            ],
          ),
          const SizedBox(height: 10),
          RecommendedPlaces(),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Nearby From You",
                style: Theme.of(context).textTheme.titleLarge,
              ),
              TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, "/nearbyPlaces");
                },
                child: const Text("View All"),
              ),
            ],
          ),
          const SizedBox(height: 10),
          NearbyPlaces(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Ionicons.home_outline),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Ionicons.bookmark_outline),
            label: "Tourist Details",
          ),
          // Uncomment or add more BottomNavigationBarItems here if needed
        ],
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushNamed(context, "/home");
              break;
            case 1:
              Navigator.pushNamed(
                context,
                "/touristDetail",
                arguments: {'image': 'assets/places/place7.jpg'},
              );
              break;
          }
        },
      ),
    );
  }
}

class PlacesSearch extends SearchDelegate<PlaceModel> {
  final List<PlaceModel> places;

  PlacesSearch(this.places);

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        close(context, PlaceModel(name: '', image: ''));
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    final List<PlaceModel> results = places
        .where(
            (place) => place.name.toLowerCase().contains(query.toLowerCase()))
        .toList();

    return ListView.builder(
      itemCount: results.length,
      itemBuilder: (context, index) {
        final place = results[index];
        return ListTile(
          title: Text(place.name),
          leading: Image.asset(place.image,
              width: 50, height: 50, fit: BoxFit.cover),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => TouristDetailsPage(image: place.image),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    final List<PlaceModel> suggestions = places
        .where(
            (place) => place.name.toLowerCase().contains(query.toLowerCase()))
        .toList();

    return ListView.builder(
      itemCount: suggestions.length,
      itemBuilder: (context, index) {
        final place = suggestions[index];
        return ListTile(
          title: Text(place.name),
          leading: Image.asset(place.image,
              width: 50, height: 50, fit: BoxFit.cover),
          onTap: () {
            query = place.name;
            showResults(context);
          },
        );
      },
    );
  }
}
